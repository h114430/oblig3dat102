package no.hvl.dat102.klient;

import java.util.*;
import no.hvl.dat102.KjedetBSTre;

public class KlientBSTre2 {
	
	/**
	 * @param args
	 */

	public static void main(String[] args) {
		
		
		int antalltre = 10;
		int antallnoder = 100;
		
		for (int i = 0; i < antalltre; i++) {
			KjedetBSTre<Integer> bstre = new KjedetBSTre<Integer>();
			for (int j = 0; j < antallnoder; j++) {
				int tilf = (int)(Math.random());
				bstre.leggTil(tilf);
				System.out.println(tilf);
			}
			
			System.out.println(bstre.hoyde(bstre.getRot()));
		}
		
		

	}

}
