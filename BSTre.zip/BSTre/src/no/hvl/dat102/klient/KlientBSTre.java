package no.hvl.dat102.klient;

import java.util.Random;

import no.hvl.dat102.KjedetBSTre;

public class KlientBSTre {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Random random = new Random(); 

		int traer = 10000; 
		int noder = 8192;
		int min = 9999; 
		int max = -1; 
		double tot = 0;

		System.out.println("Antall noder = " + noder); 

		System.out.println("St�rste teoretiske h�yde = " + (noder-1)); 

		System.out.println("Minste teoretiske h�yde = " +((int)Math.ceil(Math.log(noder +  

                1) / Math.log(2)) - 1)); 

		for (int i = 0; i < traer; i++) { 

			KjedetBSTre<Integer> t = new KjedetBSTre<Integer>(); 

			for (int j = 0; j < noder; j++) { 

				t.leggTil(random.nextInt());

			} 

			int h = t.hoyde(t.getRot()); 

			tot+=h; 

			if (h < min) 

				min = h; 

			if(h>max) 

				max=h; 

		} 

		System.out.println("Maksimale h�yde = " + max); 

		System.out.println("Minimale h�yde = " + min); 

		System.out.println("Gjennomsnittlig h�yde= "+((double)tot/traer)); 
		
//		
//		KjedetBSTre bstre = new KjedetBSTre();
//
//		bstre.leggTil(7);
//		bstre.leggTil(5);
//		bstre.leggTil(6);
//		bstre.leggTil(4);
//		bstre.leggTil(9);
//		bstre.leggTil(10);
//		bstre.leggTil(8);
//		bstre.leggTil(3);
//		
//		System.out.println(bstre.hoyde(bstre.getRot()));
//
//		// Tester p� sortert utskrift
//		System.out.println("Skriver ut elementene sortert i bs-treet");
//		bstre.visInorden();
//
//		// Tester p� om et bestemt element fins
//		int element = 8;
//		System.out.println("\nTester paa om elementet " + element + " fins");
//
//		if (bstre.finn(element) != null) {
//			System.out.println("Elementet " + element + " fins i bs-treet");
//		} else {
//			System.out.println("Elementet " + element + " fins ikke i bs-treet");
//		}
//
//		element = 1;
//		System.out.println("\nTester paa om elementet " + element + " fins");
//
//		if (bstre.finn(element) != null) {
//			System.out.println("Elementet " + element + " fins i bs-treet");
//		} else {
//			System.out.println("Elementet " + element + " fins ikke i bs-treet");
//		}
	}

}
